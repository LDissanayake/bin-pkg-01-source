<?php
/**
 * Plugin Name: Addifect Dev
 * Plugin URI: https://addifect.com
 * Description: Addifect Dev.
 * Version: 1.0.0
 * Author: Lahiru Dissanayake
 * Author URI: https://x.com/lahirunayak
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: addifect-dev
 * Domain Path: /languages
 *
 * @package AddifectDev
 */

// Hook into the 'init' action to check for the 'dev' parameter in the URL.
add_action( 'init', 'addifect_check_dev_mode' );

/**
 * Check the URL for the 'dev' parameter and update the development mode option.
 */
function addifect_check_dev_mode() {
	// Check if the 'dev' parameter is set in the URL.
	if ( isset( $_GET['dev'] ) ) {
		// Get the value of the 'dev' parameter.
		$dev_mode = $_GET['dev'] === 'true';

		// Update the 'addifect_dev_env' option with the value of the 'dev' parameter.
		update_option( 'addifect_dev_env', $dev_mode );

		// Optionally, you can add an admin notice to indicate the change.
		add_action( 'admin_notices', 'addifect_dev_mode_notice' );
	}
}

/**
 * Display an admin notice indicating the development mode status.
 */
function addifect_dev_mode_notice() {
	// Get the current value of the 'addifect_dev_env' option.
	$dev_mode = get_option( 'addifect_dev_env', false );

	// Set the message based on the development mode status.
	$message = $dev_mode ? 'Development mode is now enabled.' : 'Development mode is now disabled.';

	// Display the admin notice.
	echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
}


add_action( 'init', 'addifect_dev_add_filter' );


function addifect_dev_add_filter() {

	$dev_mode = get_option( 'addifect_dev_env', false );

	if ( $dev_mode ) {
		add_filter(
			'addifect_vendor_url',
			function () {
				return 'http://localhost:3000/render-vendors.js';
			}
		);

		add_filter(
			'addifect_render_url',
			function () {
				return 'http://localhost:3000/render.js';
			}
		);

		add_filter(
			'addifect_admin_url',
			function () {
				return 'http://localhost:3006/index.js';
			}
		);

		// new.
		add_filter(
			'addifect_editor_vendor_url',
			function () {
				return 'http://localhost:3000/index-vendors.js';
			}
		);
		add_filter(
			'addifect_editor_url',
			function () {
				return 'http://localhost:3000/index.js';
			}
		);

	}
}
